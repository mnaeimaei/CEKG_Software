

    export const startButton = document.querySelector('#finishDiv input[name="BroweserButtonMode"]');


    export const startDivContainer = document.getElementById('finishDiv');

