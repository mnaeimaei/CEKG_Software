export const nextButtonFormSubmit = document.querySelector('#nextButtonC35Div input[name="nextButton1Mode"]');

export const progressBar = document.getElementById('progressBar');


export const formC35 = document.getElementById('allFormC35');

