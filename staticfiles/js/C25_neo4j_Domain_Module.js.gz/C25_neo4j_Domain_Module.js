export const nextButtonFormSubmit = document.querySelector('#nextButtonC25Div input[name="nextButton1Mode"]');

export const progressBar = document.getElementById('progressBar');


export const formC25 = document.getElementById('allFormC25');