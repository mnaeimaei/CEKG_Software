export const nextButtonFormSubmit = document.querySelector('#nextButtonC26Div input[name="nextButton1Mode"]');

export const progressBar = document.getElementById('progressBar');


export const formC26 = document.getElementById('allFormC26');