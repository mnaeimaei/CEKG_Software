export const nextButtonFormSubmit = document.querySelector('#nextButtonC28Div input[name="nextButton1Mode"]');

export const progressBar = document.getElementById('progressBar');


export const formC28 = document.getElementById('allFormC28');