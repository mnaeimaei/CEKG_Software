export const nextButtonFormSubmit = document.querySelector('#nextButtonC34Div input[name="nextButton1Mode"]');

export const progressBar = document.getElementById('progressBar');

export const formC34 = document.getElementById('allFormC34');