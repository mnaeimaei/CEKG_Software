export const nextButtonFormSubmit = document.querySelector('#nextButtonC20Div input[name="nextButton1Mode"]');
export const progressBar = document.getElementById('progressBar');


export const formC20 = document.getElementById('allFormC20');