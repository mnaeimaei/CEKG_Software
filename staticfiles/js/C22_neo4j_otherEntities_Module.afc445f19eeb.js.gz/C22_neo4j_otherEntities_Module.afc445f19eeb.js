export const nextButtonFormSubmit = document.querySelector('#nextButtonC22Div input[name="nextButton1Mode"]');

export const progressBar = document.getElementById('progressBar');


export const formC22 = document.getElementById('allFormC22');