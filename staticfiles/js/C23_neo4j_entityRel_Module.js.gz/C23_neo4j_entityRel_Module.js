export const nextButtonFormSubmit = document.querySelector('#nextButtonC23Div input[name="nextButton1Mode"]');

export const progressBar = document.getElementById('progressBar');

export const formC23 = document.getElementById('allFormC23');