

    export const userNameBox = document.querySelector('#mainLoginDiv input[name="usernameMode"]');
    export const passWordBox = document.querySelector('#mainLoginDiv input[name="passwordMode"]');
    export const loginButton = document.querySelector('#submitDiv input[name="LoginButtonMode"]');

    export const userNameDivContainer = document.getElementById('mainLoginDiv');

    export const passWordDivContainer = document.getElementById('mainLoginDiv');

    export const loginDivContainer = document.getElementById('submitDiv');

