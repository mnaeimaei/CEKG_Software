export const nextButtonFormSubmit = document.querySelector('#nextButtonC33Div input[name="nextButton1Mode"]');

export const progressBar = document.getElementById('progressBar');


export const formC33 = document.getElementById('allFormC33');