export const nextButtonFormSubmit = document.querySelector('#nextButtonC27Div input[name="nextButton1Mode"]');

export const progressBar = document.getElementById('progressBar');


export const formC27 = document.getElementById('allFormC27');