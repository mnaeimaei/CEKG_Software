export const nextButtonFormSubmit = document.querySelector('#nextButtonC31Div input[name="nextButton1Mode"]');

export const progressBar = document.getElementById('progressBar');


export const formC31 = document.getElementById('allFormC31');