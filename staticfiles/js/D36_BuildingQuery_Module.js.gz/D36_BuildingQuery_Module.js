
export const nextButton2FormSubmit = document.querySelector('#nextButton3Div input[name="nextButton1Mode"]');

export const progressBar = document.getElementById('progressBar');
export const formC20 = document.getElementById('allFormC20');