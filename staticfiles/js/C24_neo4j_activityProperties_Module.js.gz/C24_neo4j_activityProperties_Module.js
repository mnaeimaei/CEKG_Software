export const nextButtonFormSubmit = document.querySelector('#nextButtonC24Div input[name="nextButton1Mode"]');

export const progressBar = document.getElementById('progressBar');

export const formC24 = document.getElementById('allFormC24');