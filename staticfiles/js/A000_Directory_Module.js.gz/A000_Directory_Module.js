

    export const startButton = document.querySelector('#submitDiv input[name="StartButtonMode"]');


    export const startDivContainer = document.getElementById('submitDiv');

