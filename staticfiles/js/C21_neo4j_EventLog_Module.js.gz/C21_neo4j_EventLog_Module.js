export const nextButtonFormSubmit = document.querySelector('#nextButtonC21Div input[name="nextButton1Mode"]');
export const progressBar = document.getElementById('progressBar');


export const formC21 = document.getElementById('allFormC21');